# arm-base
This repo has all the core building blocks pertaining to azure services 

#Usage

###Vocabulary
* local - local repository
* remote - remote repository

###Pre Requisites
* Install [GIT](https://git-scm.com/downloads)
* Install [VS Code](https://code.visualstudio.com/b#alt-downloads)
* Set up GIT with user credentials by following [this](https://help.github.com/articles/set-up-git/)
* VS Code & GIT [here](https://johnpapa.net/git-and-preferences-in-visual-studio-code/) | [here](https://git-scm.com/book/en/v2/Getting-Started-Git-Basics) | [here](https://www.sitepoint.com/git-for-beginners/)

###Before we begin
#####Cloning to the local
* Navigate to a folder of choice and clone the repo locally using `git clone repoURL` (Ex- arm-base)
![](https://armbaseartifacts.blob.core.windows.net/arm-base/arm-base-images/git-clone-command.png)
* Open up VSCode and `File > Open Folder` to open up the repo folder.
* Files from the remote repo should now appear on the left files explorer.
* Should see a label `master` on the lower left end corner of VSCode.
![](https://armbaseartifacts.blob.core.windows.net/arm-base/arm-base-images/vscode.png)
* Proceed with installing necessary plugins.

#####Branching out to begin working
* Click on the label `master` at the lower left corner of VSCode (this depicts current branch)
* This opens up the cmd pallet on the main coding screen with a drop down.
* Choose the option that says `staging`.
![](https://armbaseartifacts.blob.core.windows.net/arm-base/arm-base-images/change-to-staging.png)
* Now the label that read `master` before should now read `staging`.
![](https://armbaseartifacts.blob.core.windows.net/arm-base/arm-base-images/staging.png)
* Repeat the same process as above to open up the cmd pallet with a drop down, now simply type the name of the `resource` or `component` or `solution` that is intented to be developed to create a new branch (Ex- test2) from `staging` branch locally. Make sure to do a pull on staging to have all the updates from remote to local
![](https://armbaseartifacts.blob.core.windows.net/arm-base/arm-base-images/pull-on staging.png)
![](https://armbaseartifacts.blob.core.windows.net/arm-base/arm-base-images/branch-onstaging.png)
* Now create a folder to house your development and add a `ReadMe.md` inside the folder.
* Also add the a `YourComponentName.feature` file to the tests folder.

#####Commiting to local
* Now with the `ReadMe.md` file added, you should see badges on the GIT icon on the left appbar of VSCode.
* Click GIT icon to see changes to the files.
* Goal is to `stage` all the changes before `commit`.
* If you see files under `changes`, click on the `+` icon to the right of the file name to stage it.
* Once staged enter a commit message and click on the "tick" to commit the changes locally.
![](https://armbaseartifacts.blob.core.windows.net/arm-base/arm-base-images/changes.png)

#####Push Branch to Remote
* Now click on the `...` icon to `push` or `publish`
* `Publish` is to create your branch on the remote and then `push` the changes from local to remote.
* `Push` is to push changes from local to remote if your branch already exists on remote.
![](https://armbaseartifacts.blob.core.windows.net/arm-base/arm-base-images/publish.png)

#####Creating a Pull Request
* Navigate to github.
* Confirm if you can see your branch / changes / commits
* Follow github GUI to create a pull request. ( make sure base is `staging` )
![](https://armbaseartifacts.blob.core.windows.net/arm-base/arm-base-images/pull-on-gitui.png)
![](https://armbaseartifacts.blob.core.windows.net/arm-base/arm-base-images/pull-on-gitui2.png)

#####Configuring Jenkins Jobs
* Navigate to the `http://54.200.132.34:8080/` to access jenkins.( to get access [mail](mailto:pkishen@sysgain.com?subject=access to jenkins))
* From the left menu `New Item > copy from existing` and choose `arm-base-staging`, also give the job the same name as the branch name.
* Once the job is created click the `JobName` to open it up.
* Now click on the `configure` button on the left menu bar.
* Find `Branches to build` and add your branch name `*/BranchName`.
* Traverse farther down to `Admin list` to add your name.
* Traverse farther down to `Execute Shell` and find the one that has `vbnet-subnet.feature` replace that with `YourComponentName.feature`
* Click `Save` to complete configuring the jenkins job.