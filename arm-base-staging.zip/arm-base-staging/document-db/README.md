This file contains armbase component of document-db
