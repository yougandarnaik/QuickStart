### This folder contains Azure SQL Database base template.
