### This folder contains Azure SQL Datawarehouse base template.
