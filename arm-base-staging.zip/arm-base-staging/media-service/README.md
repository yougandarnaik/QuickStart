### This folder contain media services base module

-It requires storage account name so that media service work properly.
