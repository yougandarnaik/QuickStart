###Availability Set base module
