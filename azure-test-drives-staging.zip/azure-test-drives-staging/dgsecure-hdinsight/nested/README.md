dataguise nested templates
