# azure-test-drives
## Staging
This is the branch where all Azure test drive templates  and manual currently in Staging/Testing stage are maintained.

Once validated, any templates and/or manuals in Staging should have a pull request created to merge with the main branch respective to the Partner.
